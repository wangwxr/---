#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <string>
#include <map>

using namespace std;

class Polynomial {
private:
    map<int, double> terms;

public:
    void addTerm(int exponent, double coefficient) {
        if (terms.find(exponent) != terms.end()) {
            terms[exponent] += coefficient;
            if (terms[exponent] == 0) {
                terms.erase(exponent);
            }
        }
        else {
            terms[exponent] = coefficient;
        }
    }

    Polynomial operator+(const Polynomial& other) const {
        Polynomial result = *this;
        for (auto& term : other.terms) {
            result.addTerm(term.first, term.second);
        }
        return result;
    }

    Polynomial operator-(const Polynomial& other) const {
        Polynomial result = *this;
        for (auto& term : other.terms) {
            result.addTerm(term.first, -term.second);
        }
        return result;
    }

    Polynomial operator*(const Polynomial& other) const {
        Polynomial result;
        for (auto& thisTerm : this->terms) {
            for (auto& otherTerm : other.terms) {
                int exp = thisTerm.first + otherTerm.first;
                double coeff = thisTerm.second * otherTerm.second;
                result.addTerm(exp, coeff);
            }
        }
        return result;
    }

    // �򵥵ĳ���ʵ�֣��������������
    Polynomial operator/(const Polynomial& other) const {
        Polynomial result;
        // ��򵥵�������������������ǵ���ʽʱ�����
        if (other.terms.size() == 1) {
            int otherExp = other.terms.begin()->first;
            double otherCoeff = other.terms.begin()->second;
            for (auto& thisTerm : this->terms) {
                int exp = thisTerm.first - otherExp;
                double coeff = thisTerm.second / otherCoeff;
                result.addTerm(exp, coeff);
            }
        }
        return result;
    }

    string toString() const {
        string result;
        for (auto it = terms.rbegin(); it != terms.rend(); ++it) {
            if (!result.empty() && it->second > 0) result += "+";
            result += to_string(it->second) + "x^" + to_string(it->first) + " ";
        }
        return result.empty() ? "0" : result;
    }
};

Polynomial generateRandomPolynomial(int maxDegree, int maxCoefficient, bool hasDecimal) {
    Polynomial poly;
    int termCount = rand() % maxDegree + 1;
    for (int i = 0; i < termCount; i++) {
        int exp = rand() % (maxDegree + 1);
        double coeff = hasDecimal ? (rand() % (2 * maxCoefficient + 1)) - maxCoefficient + (rand() % 10) / 10.0
            : (rand() % (2 * maxCoefficient + 1)) - maxCoefficient;
        poly.addTerm(exp, coeff);
    }
    return poly;
}

int main() {
    srand(time(NULL));
    int numProblems, maxDegree, maxCoefficient;
    bool hasDecimal;
    string operations, outputMethod, filename;

    cout << "��������Ŀ������";
    cin >> numProblems;
    cout << "��������ߴ��ݣ�";
    cin >> maxDegree;
    cout << "���������ϵ������������";
    cin >> maxCoefficient;
    cout << "�Ƿ����С��ϵ������1Ϊ�ǣ�0Ϊ�񣩣�";
    cin >> hasDecimal;
    cout << "�������������+,-,*,/���޿ո񣩣�";
    cin >> operations;
    cout << "������ļ����ǿ���̨����file/console����";
    cin >> outputMethod;

    vector<Polynomial> problems;
    vector<string> answers;

    // ������Ŀ�ʹ�
    for (int i = 0; i < numProblems; i++) {
        Polynomial p1 = generateRandomPolynomial(maxDegree, maxCoefficient, hasDecimal);
        Polynomial p2 = generateRandomPolynomial(maxDegree, maxCoefficient, hasDecimal);
        char operation = operations[rand() % operations.length()];
        Polynomial answer;

        switch (operation) {
        case '+':
            answer = p1 + p2;
            break;
        case '-':
            answer = p1 - p2;
            break;
        case '*':
            answer = p1 * p2;
            break;
        case '/':
            answer = p1 / p2;
            break;
        default:
            continue;
        }

        string problem = "(" + p1.toString() + ") " + operation + " (" + p2.toString() + ")";
        answers.push_back(problem + " = " + answer.toString());
    }

    // ���
    if (outputMethod == "file") {
        cout << "�������ļ�����";
        cin >> filename;
        ofstream outFile(filename);
        for (const string& answer : answers) {
            outFile << answer << endl;
        }
        outFile.close();
    }
    else {
        for (const string& answer : answers) {
            cout << answer << endl;
        }
    }

    return 0;
}
